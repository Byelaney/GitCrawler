/**
 * Code for the Java course at the University of Cologne, Department of Linguistics 
 * (Sprachliche Informationsverarbeitung, http://github.com/spinfo).
 **/
package spinfo;